create definer = swcamp@`%` view v_menu as
select `menudb`.`tbl_menu`.`menu_name`  AS `menu_name`,
       `menudb`.`tbl_menu`.`menu_price` AS `menu_price`,
       `menudb`.`tbl_menu`.`menu_code`  AS `menu_code`
from `menudb`.`tbl_menu`;

-- comment on column v_menu.menu_name not supported: 메뉴명

-- comment on column v_menu.menu_price not supported: 메뉴가격

-- comment on column v_menu.menu_code not supported: 메뉴코드

